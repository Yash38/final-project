# AndroidProject
A Employee Registry app with SQL Database.
Made By-
Asritha Surabhi-C0748835
Jaspreet-C0747060
Ganesh Reddy Padala-C0748497
Gurjeet Ratan-C0735889
